-- phpMyAdmin SQL Dump
-- version 4.9.7
-- https://www.phpmyadmin.net/
--
-- Host: localhost:3306
-- Creato il: Set 28, 2021 alle 13:43
-- Versione del server: 10.3.24-MariaDB-cll-lve
-- Versione PHP: 7.3.30

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `nis_laravel`
--

-- --------------------------------------------------------

--
-- Struttura della tabella `failed_jobs`
--

CREATE TABLE `failed_jobs` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `uuid` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `connection` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `queue` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `payload` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `exception` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `failed_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Struttura della tabella `migrations`
--

CREATE TABLE `migrations` (
  `id` int(10) UNSIGNED NOT NULL,
  `migration` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dump dei dati per la tabella `migrations`
--

INSERT INTO `migrations` (`id`, `migration`, `batch`) VALUES
(1, '2014_10_12_000000_create_users_table', 1),
(2, '2014_10_12_100000_create_password_resets_table', 1),
(3, '2016_06_01_000001_create_oauth_auth_codes_table', 1),
(4, '2016_06_01_000002_create_oauth_access_tokens_table', 1),
(5, '2016_06_01_000003_create_oauth_refresh_tokens_table', 1),
(6, '2016_06_01_000004_create_oauth_clients_table', 1),
(7, '2016_06_01_000005_create_oauth_personal_access_clients_table', 1),
(8, '2019_08_19_000000_create_failed_jobs_table', 1),
(9, '2019_12_14_000001_create_personal_access_tokens_table', 1);

-- --------------------------------------------------------

--
-- Struttura della tabella `oauth_access_tokens`
--

CREATE TABLE `oauth_access_tokens` (
  `id` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `user_id` bigint(20) UNSIGNED DEFAULT NULL,
  `client_id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `scopes` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `revoked` tinyint(1) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `expires_at` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dump dei dati per la tabella `oauth_access_tokens`
--

INSERT INTO `oauth_access_tokens` (`id`, `user_id`, `client_id`, `name`, `scopes`, `revoked`, `created_at`, `updated_at`, `expires_at`) VALUES
('06c1aead304c159be49d622e3525ebf044ee9ce58095f4f04585ae1a454501b3509c55207a23f4c8', 2, 1, 'authToken', '[]', 1, '2021-09-25 06:05:39', '2021-09-25 06:05:39', '2022-09-25 09:05:39'),
('12ee546eb902e1b01af2c91f481c62ac632a975da51bf68faad63022a039188b12c6a0b1bdcacc4c', 2, 1, 'authToken', '[]', 1, '2021-09-25 06:34:47', '2021-09-25 06:34:47', '2022-09-25 09:34:47'),
('1c15bf6964a716349348b49f161d5f143cb0de19730673c737975fcd08ed830d9755e1e1b66ebb5f', 1, 1, 'authToken', '[]', 0, '2021-09-24 14:01:47', '2021-09-24 14:01:47', '2022-09-24 17:01:47'),
('1cd483fa4b7fd7bee9af9a960173105a398a02e8151142c128f67f7105fe9d13bb828d56c07e777c', 10, 1, 'authToken', '[]', 0, '2021-09-26 07:50:50', '2021-09-26 07:50:50', '2022-09-26 10:50:50'),
('1fc49e1a777d35d751f53db13426d10c5da4a996ea3e8dfbe849be7e12e90715fdb33b5ebca1cd87', 2, 1, 'authToken', '[]', 1, '2021-09-25 06:29:44', '2021-09-25 06:29:44', '2022-09-25 09:29:44'),
('2554601fb55d9728b21811aa314b46cd5594801e4ae627f6be0c5ddedf243a3a07e468bc73970704', 10, 1, 'authToken', '[]', 1, '2021-09-26 07:50:07', '2021-09-26 07:50:07', '2022-09-26 10:50:07'),
('2ab864b944d0e34d29f4c15cbd53e81ddde38fc89c06b8f5790b375bc1c834f400982d35054a3a06', 9, 1, 'authToken', '[]', 1, '2021-09-26 06:41:14', '2021-09-26 06:41:14', '2022-09-26 09:41:14'),
('316d7593ffa1f10e2725bca6f381da325b403a4cfe2f42b966292396db5008148860a26d0714ee75', 29, 1, 'authToken', '[]', 1, '2021-09-26 11:47:51', '2021-09-26 11:47:51', '2022-09-26 14:47:51'),
('33609fbb95167108d8340c3a6287a6f93162d96d791ba4e010e6ae86912f8d0b6f8d9cccafce378b', 2, 1, 'authToken', '[]', 1, '2021-09-25 06:10:38', '2021-09-25 06:10:38', '2022-09-25 09:10:38'),
('383d370b67f32db64f7b5c461c83ca3cc094d023c865a0dc1b709cc689bd7cdbd01af67f3fc277a9', 2, 1, 'authToken', '[]', 1, '2021-09-25 06:37:08', '2021-09-25 06:37:08', '2022-09-25 09:37:08'),
('39f1b4da8d3e66ad8dbd2f08eb9ac40d786cc418936c93146817df38ac8a119989dcf7e38532c958', 29, 1, 'authToken', '[]', 1, '2021-09-26 11:09:39', '2021-09-26 11:09:39', '2022-09-26 14:09:39'),
('413460af3c203175bb6b8bc832d9fe016c401665804fc1eca06333df9637b42b853c666add40630a', 10, 1, 'authToken', '[]', 1, '2021-09-26 07:43:53', '2021-09-26 07:43:53', '2022-09-26 10:43:53'),
('4246571a6daf0c6d5b6027681fba5c38b7ea00ceb28a36cd5cbbe24c511cfaaf941e7bcbce7e32ba', 2, 1, 'authToken', '[]', 1, '2021-09-25 06:02:14', '2021-09-25 06:02:14', '2022-09-25 09:02:14'),
('4397fa9f60818ddf22f4379811ecc68a1c62514650f8b82160f36f4d9ea22d68d1f06316b0e87670', 2, 1, 'authToken', '[]', 1, '2021-09-25 06:29:04', '2021-09-25 06:29:04', '2022-09-25 09:29:04'),
('4807a775340fcc6f93e2c1fbd29e5d6ec00465c702c30a0657219b42dea24e9ed57ccf8b4b3719c2', 2, 1, 'authToken', '[]', 1, '2021-09-25 06:04:38', '2021-09-25 06:04:38', '2022-09-25 09:04:38'),
('4e4e0c46403569b40f80896d2cb884b676fd50aecb4280c811e32e94b50c9d815fc64d8f3b735005', 2, 1, 'authToken', '[]', 1, '2021-09-25 07:03:24', '2021-09-25 07:03:24', '2022-09-25 10:03:24'),
('4e687d8af70d92de660049b6d4cbbfae731ee6c11290c2b8906ffbac18cc85aa7882346c722a1b4f', 2, 1, 'authToken', '[]', 1, '2021-09-25 06:00:58', '2021-09-25 06:00:58', '2022-09-25 09:00:58'),
('55038053feef9302d130b4ee7ca26f13a5cd853bed692890919045f6554e4be66fe1c1c1bac1394b', 10, 1, 'authToken', '[]', 0, '2021-09-26 07:51:01', '2021-09-26 07:51:01', '2022-09-26 10:51:01'),
('56eaa596d12a0e2b88528ede372156257e821baebac6ecc0afc9eac23e5117cbab47ed8ec3faf8aa', 2, 1, 'authToken', '[]', 1, '2021-09-25 06:35:22', '2021-09-25 06:35:22', '2022-09-25 09:35:22'),
('58bd8760a3f66d11c5b9b06dbf40ed3965d27446e55b213ce9258d8e6f7b04555778d6085280ffee', 29, 1, 'authToken', '[]', 0, '2021-09-28 07:36:59', '2021-09-28 07:36:59', '2022-09-28 10:36:59'),
('599b7b2f818890bea6f24d8050a5724541197dc2324845f9278900c402768a2a2a0528ab0e3b3c57', 2, 1, 'authToken', '[]', 1, '2021-09-25 08:06:17', '2021-09-25 08:06:17', '2022-09-25 11:06:17'),
('5d062fb8b4c9db0fc9e0bb4255d75fdd347787078b93339e9bc7ccdd1cb57d152119836b275c3791', 2, 1, 'authToken', '[]', 1, '2021-09-25 06:45:34', '2021-09-25 06:45:34', '2022-09-25 09:45:34'),
('64d9cdcc71291ccab53d8a31f82feec38e7e11be161329b6ae48c7fabe8be520339b6c9b5e3e377e', 2, 1, 'authToken', '[]', 1, '2021-09-25 06:12:59', '2021-09-25 06:12:59', '2022-09-25 09:12:59'),
('65593504b64d3d499780e1414cb1c88293d4d40cb039fda1d868efa729ad87db91f9879e8819f623', 2, 1, 'authToken', '[]', 1, '2021-09-25 06:14:16', '2021-09-25 06:14:16', '2022-09-25 09:14:16'),
('6680e1e57ca8e415325f6e650fa0fd7a229f3a9b1eab82037df081d3d5938d85bb6fc190c0afad0d', 2, 1, 'authToken', '[]', 1, '2021-09-25 07:19:59', '2021-09-25 07:19:59', '2022-09-25 10:19:59'),
('7497565c0244217ef91dc941f4416e59e1503d24e6c8bb15b61e7593da8a6e6afe896141003c406a', 2, 1, 'authToken', '[]', 1, '2021-09-25 06:11:12', '2021-09-25 06:11:12', '2022-09-25 09:11:12'),
('754e39c1574c0f4e1705cc7c25642fad180a6c85daf021a0b550fe1ca5c9661959474687c0679a89', 29, 1, 'authToken', '[]', 1, '2021-09-26 11:02:03', '2021-09-26 11:02:03', '2022-09-26 14:02:03'),
('7b062c08c241d29c2c6ca3bbb9afc58042046e5ad799b9ddabd6abfa3867ff8ba1426a64e43783d7', 2, 1, 'authToken', '[]', 1, '2021-09-25 07:17:23', '2021-09-25 07:17:23', '2022-09-25 10:17:23'),
('7e9a909dbd5df8d05176ad72ca773b752a6d6c46d890767bc1948c6be3a672b2b2faf2a5a21df506', 2, 1, 'authToken', '[]', 1, '2021-09-25 06:47:28', '2021-09-25 06:47:28', '2022-09-25 09:47:28'),
('7fc087132d6f1314e9fad1964b6648ad3ec3c117d3fed20400fcf78b91c128dc475cf332c67b4b0a', 2, 1, 'authToken', '[]', 1, '2021-09-25 07:10:37', '2021-09-25 07:10:37', '2022-09-25 10:10:37'),
('803d897d69201156a57c3f70144a4e29c23dd7ce82e8536d3cf2e8044035a93b3e2cb047fa9d4030', 2, 1, 'authToken', '[]', 1, '2021-09-25 06:19:46', '2021-09-25 06:19:46', '2022-09-25 09:19:46'),
('8676cc4568e3a44fc10d12c874b4c745a9e5fe367f8562fc698609d1b222a8fb4e63c45531771357', 2, 1, 'authToken', '[]', 1, '2021-09-25 06:15:30', '2021-09-25 06:15:30', '2022-09-25 09:15:30'),
('878f135ccce4ef069786e3c930fa540d5ab258e1a2d110f6cd08a48d7071b89a55f703827fb88a92', 2, 1, 'authToken', '[]', 1, '2021-09-25 06:13:33', '2021-09-25 06:13:33', '2022-09-25 09:13:33'),
('892da0aab6f918010823061f4ee1a611f9710f15a9619b9a64ef368879eef799d0205ecacc85eb85', 2, 1, 'authToken', '[]', 1, '2021-09-25 06:47:46', '2021-09-25 06:47:46', '2022-09-25 09:47:46'),
('89ea5a225f462de98028bdef45a6b949e5365fc44f19a94f8d3e8ecfbcf5157baf713caeb9281032', 2, 1, 'authToken', '[]', 1, '2021-09-25 07:03:10', '2021-09-25 07:03:10', '2022-09-25 10:03:10'),
('8a90f082e37cefba9e40efc9317a1ceb7c3d3dacbfea78105e507f5a15fdbd0a8cd0e16fc9c632e5', 2, 1, 'authToken', '[]', 1, '2021-09-25 06:01:35', '2021-09-25 06:01:35', '2022-09-25 09:01:35'),
('90481a1f9cc2b5ba44b33045ac3dc7bfea1c9033d3167831154f943f9b29560ad2339cbcaf6580f6', 2, 1, 'authToken', '[]', 1, '2021-09-24 18:42:30', '2021-09-24 18:42:30', '2022-09-24 21:42:30'),
('916ad76ed5fdf03386113c1b1d72c8c6761dd97704a1961945fd92dab74d814bef7a31bf9d4d4fd1', 2, 1, 'authToken', '[]', 1, '2021-09-25 06:04:55', '2021-09-25 06:04:55', '2022-09-25 09:04:55'),
('930242e8ad341db9e5044526aeab33d43478e972151ebce80fad3922e8e3287dbbbc09b6506e8ecd', 2, 1, 'authToken', '[]', 0, '2021-09-25 06:19:24', '2021-09-25 06:19:24', '2022-09-25 09:19:24'),
('94eb6d469708511d76da47bc00b02c25e9d53c7839fd561e032931e3b3b3b60978b3c6fd52bbd948', 2, 1, 'authToken', '[]', 1, '2021-09-25 06:54:27', '2021-09-25 06:54:27', '2022-09-25 09:54:27'),
('98b89df3687887171af79d4af76c6170caf068210a25de26f80718094bc5235f3400cb0a1c1d0f57', 2, 1, 'authToken', '[]', 1, '2021-09-25 06:46:04', '2021-09-25 06:46:04', '2022-09-25 09:46:04'),
('9a0ea9abf7f09918e22d215c4cc54495cc82924ddb4d7a635515d93fc7498a6e38dbd11839ef8d35', 29, 1, 'authToken', '[]', 0, '2021-09-28 07:06:50', '2021-09-28 07:06:50', '2022-09-28 10:06:50'),
('9d18f11bdd735d5c19bf125fb11662e0dce5b935e42940f9e6430e0d6a037ca879f6c9bedf099d0a', 10, 1, 'authToken', '[]', 0, '2021-09-26 07:42:40', '2021-09-26 07:42:40', '2022-09-26 10:42:40'),
('a07f1ebaa54cefde3e5123275170c9d3e2ffe2ff8cce2c107a0556d2f1dc9242125c0f85feb31e7f', 10, 1, 'authToken', '[]', 1, '2021-09-26 07:39:36', '2021-09-26 07:39:36', '2022-09-26 10:39:36'),
('a2adb39b28dd45adbbd730b15f1f26aabe6d4bb81cdd4ade64195905c149322a89764437a591fc4a', 1, 1, 'authToken', '[]', 1, '2021-09-24 19:08:19', '2021-09-24 19:08:19', '2022-09-24 22:08:19'),
('ae77314425b07c0b01c26782135871f73695312e79026dafa32e54969c701bc0694fd2b059726207', 2, 1, 'authToken', '[]', 1, '2021-09-25 06:06:24', '2021-09-25 06:06:24', '2022-09-25 09:06:24'),
('aeea6cc03eeebf63566c39ca9e5fc6021c44803dda17468a5386c36f76adeab9b4ae962a14c084f6', 10, 1, 'authToken', '[]', 1, '2021-09-26 07:51:27', '2021-09-26 07:51:27', '2022-09-26 10:51:27'),
('b1669f3050d9f70be0aa230df82f2fc0065091a9c45497a25859345944cfc9492384bbd94b890808', 2, 1, 'authToken', '[]', 1, '2021-09-25 06:15:05', '2021-09-25 06:15:05', '2022-09-25 09:15:05'),
('b3330c6f840397cf75bf6f76d26639624ed8f0770eda2d0d6e0c805f89c9d36c788e7769d5e6dfa1', 2, 1, 'authToken', '[]', 1, '2021-09-25 05:58:01', '2021-09-25 05:58:01', '2022-09-25 08:58:01'),
('b6196f477ea1f093aac15dd6b9d2e874de2c4077baaca641699a342ab5e248961d46ac0c0bc065da', 2, 1, 'authToken', '[]', 1, '2021-09-25 06:55:56', '2021-09-25 06:55:56', '2022-09-25 09:55:56'),
('b7490d2b7e1770c158f4585387fecb076b4fce15c0af4bc7f01a7a2ad6ce511f1f8f9992e2c94081', 2, 1, 'authToken', '[]', 1, '2021-09-25 08:06:28', '2021-09-25 08:06:28', '2022-09-25 11:06:28'),
('bb85d73318eb3cce7d35670068cd1645b47c6e350fef31d42019bef9ad2d67d8e550b3407a2d9285', 29, 1, 'authToken', '[]', 0, '2021-09-28 07:11:41', '2021-09-28 07:11:41', '2022-09-28 10:11:41'),
('bd3c6e4c29c67cde8009769aeb660ab73cf86886ef754515ebe755447978df9627941022f7f49ad1', 2, 1, 'authToken', '[]', 1, '2021-09-25 06:08:17', '2021-09-25 06:08:17', '2022-09-25 09:08:17'),
('bfd23b186acae333c26ceda7550f13753f55aee4c81c14593934f7f08ae5a78dea74bf8572135336', 2, 1, 'authToken', '[]', 1, '2021-09-25 06:17:02', '2021-09-25 06:17:02', '2022-09-25 09:17:02'),
('c30e4934ad6383be1c9ddb80cc507666c8c601878cb8a24b4dd456126efb9fb3add6f31617ec0840', 2, 1, 'authToken', '[]', 1, '2021-09-25 07:59:36', '2021-09-25 07:59:36', '2022-09-25 10:59:36'),
('cb015a8853042b8b76ae94d286a896c5df9f5fcb098cb8aa089225fd5c92e6df01133dc8219a17dc', 2, 1, 'authToken', '[]', 0, '2021-09-24 18:34:19', '2021-09-24 18:34:19', '2022-09-24 21:34:19'),
('cdd417a41ac4d0fe37a4c98b68c9ef90bfa7fc24eb6d0b36923a34be2614aab981f6887d2b2cd50a', 2, 1, 'authToken', '[]', 1, '2021-09-25 07:03:19', '2021-09-25 07:03:19', '2022-09-25 10:03:19'),
('d2aa6b1b2443ef8b83f4eb319954b481fc167084ffafbadc493c4436391e68dd53802849c5e9b5f1', 1, 1, 'authToken', '[]', 0, '2021-09-24 14:05:45', '2021-09-24 14:05:45', '2022-09-24 17:05:45'),
('e82425bb1b6af9034f6aee412cbe7f40edb4acb9df692ba27bb3b9b2408dcdc425e3e1b291151826', 10, 1, 'authToken', '[]', 0, '2021-09-26 07:55:50', '2021-09-26 07:55:50', '2022-09-26 10:55:50'),
('e8b12339033b1c74e28313c7e0725e0e502dd26473ab47fce7d18b5f9cafbac9969ba99866e3a0cc', 2, 1, 'authToken', '[]', 0, '2021-09-25 06:55:56', '2021-09-25 06:55:56', '2022-09-25 09:55:56'),
('f14cb5703f704b57fb3cba3a69d2826886dd11ac7b7a92570713747e7f29edda7b4e52cd2c34309f', 29, 1, 'authToken', '[]', 1, '2021-09-26 14:54:38', '2021-09-26 14:54:38', '2022-09-26 17:54:38'),
('f1f35b6a0eb1dcced4235e1b62425e5b0a4a750c474158a25050eb845e422074cd30c16c505393f7', 2, 1, 'authToken', '[]', 1, '2021-09-25 07:03:58', '2021-09-25 07:03:58', '2022-09-25 10:03:58'),
('fd8ef7b6559bce958a707bf811dc0f1c76a06153f2461b86f396f76caf1baf1965f269c5ce2e8ff0', 2, 1, 'authToken', '[]', 1, '2021-09-25 06:10:09', '2021-09-25 06:10:09', '2022-09-25 09:10:09'),
('ff69524b1c621efc9fe81517d880e67f240db91d8c120699ced83f677c2141b097400ab00224d5c7', 2, 1, 'authToken', '[]', 1, '2021-09-25 06:09:20', '2021-09-25 06:09:20', '2022-09-25 09:09:20');

-- --------------------------------------------------------

--
-- Struttura della tabella `oauth_auth_codes`
--

CREATE TABLE `oauth_auth_codes` (
  `id` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `user_id` bigint(20) UNSIGNED NOT NULL,
  `client_id` bigint(20) UNSIGNED NOT NULL,
  `scopes` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `revoked` tinyint(1) NOT NULL,
  `expires_at` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Struttura della tabella `oauth_clients`
--

CREATE TABLE `oauth_clients` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `user_id` bigint(20) UNSIGNED DEFAULT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `secret` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `provider` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `redirect` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `personal_access_client` tinyint(1) NOT NULL,
  `password_client` tinyint(1) NOT NULL,
  `revoked` tinyint(1) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dump dei dati per la tabella `oauth_clients`
--

INSERT INTO `oauth_clients` (`id`, `user_id`, `name`, `secret`, `provider`, `redirect`, `personal_access_client`, `password_client`, `revoked`, `created_at`, `updated_at`) VALUES
(1, NULL, 'Laravel Personal Access Client', 'qqlWaVgf5jIvzELTEGt784pSGSnyrdo81a5cYjwS', NULL, 'http://localhost', 1, 0, 0, '2021-09-24 11:49:20', '2021-09-24 11:49:20'),
(2, NULL, 'Laravel Password Grant Client', 'tQUApY6eVp0paiqvMoSjhyg9mivNXO0fy2LNXNUJ', 'users', 'http://localhost', 0, 1, 0, '2021-09-24 11:49:20', '2021-09-24 11:49:20');

-- --------------------------------------------------------

--
-- Struttura della tabella `oauth_personal_access_clients`
--

CREATE TABLE `oauth_personal_access_clients` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `client_id` bigint(20) UNSIGNED NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dump dei dati per la tabella `oauth_personal_access_clients`
--

INSERT INTO `oauth_personal_access_clients` (`id`, `client_id`, `created_at`, `updated_at`) VALUES
(1, 1, '2021-09-24 11:49:20', '2021-09-24 11:49:20');

-- --------------------------------------------------------

--
-- Struttura della tabella `oauth_refresh_tokens`
--

CREATE TABLE `oauth_refresh_tokens` (
  `id` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `access_token_id` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `revoked` tinyint(1) NOT NULL,
  `expires_at` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Struttura della tabella `password_resets`
--

CREATE TABLE `password_resets` (
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Struttura della tabella `personal_access_tokens`
--

CREATE TABLE `personal_access_tokens` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `tokenable_type` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `tokenable_id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `abilities` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `last_used_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Struttura della tabella `users`
--

CREATE TABLE `users` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email_verified_at` timestamp NULL DEFAULT NULL,
  `password` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `remember_token` varchar(2048) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dump dei dati per la tabella `users`
--

INSERT INTO `users` (`id`, `name`, `email`, `email_verified_at`, `password`, `remember_token`, `created_at`, `updated_at`) VALUES
(29, 'Andrei', 'andrei.leca55@gmail.com', NULL, '$2y$10$GgkTMynE10d8izvRS3H91.xFZ3RjLuTypNPjQYUm2ZF5e70Bfe4Ky', NULL, '2021-09-26 10:53:26', '2021-09-26 10:53:26');

--
-- Indici per le tabelle scaricate
--

--
-- Indici per le tabelle `failed_jobs`
--
ALTER TABLE `failed_jobs`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `failed_jobs_uuid_unique` (`uuid`);

--
-- Indici per le tabelle `migrations`
--
ALTER TABLE `migrations`
  ADD PRIMARY KEY (`id`);

--
-- Indici per le tabelle `oauth_access_tokens`
--
ALTER TABLE `oauth_access_tokens`
  ADD PRIMARY KEY (`id`),
  ADD KEY `oauth_access_tokens_user_id_index` (`user_id`);

--
-- Indici per le tabelle `oauth_auth_codes`
--
ALTER TABLE `oauth_auth_codes`
  ADD PRIMARY KEY (`id`),
  ADD KEY `oauth_auth_codes_user_id_index` (`user_id`);

--
-- Indici per le tabelle `oauth_clients`
--
ALTER TABLE `oauth_clients`
  ADD PRIMARY KEY (`id`),
  ADD KEY `oauth_clients_user_id_index` (`user_id`);

--
-- Indici per le tabelle `oauth_personal_access_clients`
--
ALTER TABLE `oauth_personal_access_clients`
  ADD PRIMARY KEY (`id`);

--
-- Indici per le tabelle `oauth_refresh_tokens`
--
ALTER TABLE `oauth_refresh_tokens`
  ADD PRIMARY KEY (`id`),
  ADD KEY `oauth_refresh_tokens_access_token_id_index` (`access_token_id`);

--
-- Indici per le tabelle `password_resets`
--
ALTER TABLE `password_resets`
  ADD KEY `password_resets_email_index` (`email`);

--
-- Indici per le tabelle `personal_access_tokens`
--
ALTER TABLE `personal_access_tokens`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `personal_access_tokens_token_unique` (`token`),
  ADD KEY `personal_access_tokens_tokenable_type_tokenable_id_index` (`tokenable_type`,`tokenable_id`);

--
-- Indici per le tabelle `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `users_email_unique` (`email`);

--
-- AUTO_INCREMENT per le tabelle scaricate
--

--
-- AUTO_INCREMENT per la tabella `failed_jobs`
--
ALTER TABLE `failed_jobs`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT per la tabella `migrations`
--
ALTER TABLE `migrations`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT per la tabella `oauth_clients`
--
ALTER TABLE `oauth_clients`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT per la tabella `oauth_personal_access_clients`
--
ALTER TABLE `oauth_personal_access_clients`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT per la tabella `personal_access_tokens`
--
ALTER TABLE `personal_access_tokens`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT per la tabella `users`
--
ALTER TABLE `users`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=30;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
